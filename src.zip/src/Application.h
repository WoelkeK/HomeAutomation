#pragma once

#include "SetupManager.h"
#include "LightSensorController.h"
#include "LightingController.h"
#include "RollerShutterController.h"

class Application
{
  public:
    explicit Application(
  OutputManager& OutputManager,
  Mcp23017Manager& mcpManager,
  LightingContext& lightingContext,
   RollerContext& rollerContext
)
  : setupManager(
      OutputManager,
      mcpManager,
      lightingContext,
      rollerContext
    ),
    lightingController(
      OutputManager,
      lightingContext
    ),
    rollerShutterController(OutputManager, rollerContext)
{
}

    void begin()
    {
      setupManager.begin();
    }

    void update()
    {
      lightSensorController.update();
      lightingController.update();
      rollerShutterController.update();
    }

  private:
    SetupManager setupManager;
    LightSensorController lightSensorController;
    LightingController lightingController;
    RollerShutterController rollerShutterController;
};
