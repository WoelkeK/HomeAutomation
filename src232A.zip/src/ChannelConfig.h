#pragma once

// Sterownik_Master_090726 v2.0.1: konfiguracja kanałów w jednym miejscu.
// Wejścia pozostają na MCP23017, rolety zostają na lokalnych wyjściach Mega.
// Wszystkie światła korzystają z LightMapping.h i są kierowane na Waveshare Modbus RTU 32CH.
// W komentarzach podano pin Mega, który odpowiada danemu kanałowi. W przypadku przekaźników Modbus nie ma fizycznego pinu Mega, więc w komentarzu podano pin z Waveshare.

enum class InputDevice : byte
{
  MCP1,
  MCP2,
  MCP3
};

struct LightChannelConfig
{
  LightId id;
  byte sensorId;
  int buttonPin;
  InputDevice buttonDevice;
  OutputConfig output;
};

struct RollerChannelConfig
{
  byte sensorId;
  int buttonPin;
  InputDevice buttonDevice;
  OutputConfig output;
  unsigned long turnOffDelay;
};

const LightChannelConfig LIGHT_CHANNELS[noRelays1] = {
  {LightId::Garderoba, 0, 13, InputDevice::MCP1, outputForLight(LightId::Garderoba)},
  {LightId::Sportowy, 1, 12, InputDevice::MCP1, outputForLight(LightId::Sportowy)},
  {LightId::Gabinet, 2, 11, InputDevice::MCP1, outputForLight(LightId::Gabinet)},
  {LightId::Rozdzielnia, 3, 10, InputDevice::MCP1, outputForLight(LightId::Rozdzielnia)},
  {LightId::Lazienka, 4, 8, InputDevice::MCP1, outputForLight(LightId::Lazienka)},
  {LightId::Garaz, 5, 7, InputDevice::MCP1, outputForLight(LightId::Garaz)},
  {LightId::KuchniaOczka, 6, 6, InputDevice::MCP1, outputForLight(LightId::KuchniaOczka)},
  {LightId::KuchniaSufit, 7, 5, InputDevice::MCP1, outputForLight(LightId::KuchniaSufit)},
  {LightId::OswietlenieZewnetrzne1, 8, 4, InputDevice::MCP1, outputForLight(LightId::OswietlenieZewnetrzne1)},
  {LightId::RezerwaPin7, 9, 3, InputDevice::MCP1, outputForLight(LightId::RezerwaPin7)},
  {LightId::SalonStol, 10, 2, InputDevice::MCP1, outputForLight(LightId::SalonStol)},
  {LightId::SalonScianaZegar, 11, 1, InputDevice::MCP1, outputForLight(LightId::SalonScianaZegar)},
  {LightId::HolSpoty, 12, 0, InputDevice::MCP1, outputForLight(LightId::HolSpoty)},
  {LightId::SalonSufitRGB, 13, 15, InputDevice::MCP2, outputForLight(LightId::SalonSufitRGB)},
  {LightId::SalonOknoTvPlyta, 14, 14, InputDevice::MCP2, outputForLight(LightId::SalonOknoTvPlyta)},
  {LightId::SalonOczka, 15, 13, InputDevice::MCP2, outputForLight(LightId::SalonOczka)},
  {LightId::KorytarzSchodyRGB, 16, 12, InputDevice::MCP2, outputForLight(LightId::KorytarzSchodyRGB)},
  {LightId::KorytarzHolSpot2x, 17, 11, InputDevice::MCP2, outputForLight(LightId::KorytarzHolSpot2x)},
  {LightId::KorytarzOczkaSufit, 18, 10, InputDevice::MCP2, outputForLight(LightId::KorytarzOczkaSufit)},
  {LightId::Kotlownia, 19, 8, InputDevice::MCP2, outputForLight(LightId::Kotlownia)}
};

const RollerChannelConfig ROLLER_UP_CHANNELS[noRelays3] = {
  {0, 15, InputDevice::MCP3, {OutputType::ModbusRelay, 0, ROLLER_RELAY_SLAVE_ID, 1}, 30000},
  {1, 12, InputDevice::MCP3, {OutputType::ModbusRelay, 0, ROLLER_RELAY_SLAVE_ID, 3}, 30000},
  {2, 10, InputDevice::MCP3, {OutputType::ModbusRelay, 0, ROLLER_RELAY_SLAVE_ID, 5}, 30000},
  {3, 8, InputDevice::MCP3, {OutputType::ModbusRelay, 0, ROLLER_RELAY_SLAVE_ID, 7}, 30000},
  {4, 7, InputDevice::MCP3, {OutputType::ModbusRelay, 0, ROLLER_RELAY_SLAVE_ID, 9}, 30000},
  {5, 2, InputDevice::MCP3, {OutputType::ModbusRelay, 0, ROLLER_RELAY_SLAVE_ID, 11}, 30000},
  {6, 1, InputDevice::MCP3, {OutputType::ModbusRelay, 0, ROLLER_RELAY_SLAVE_ID, 13}, 30000}
};

const RollerChannelConfig ROLLER_DOWN_CHANNELS[noRelays4] = {
  {0, 14, InputDevice::MCP3, {OutputType::ModbusRelay, 0, ROLLER_RELAY_SLAVE_ID, 2}, 23000},
  {1, 13, InputDevice::MCP3, {OutputType::ModbusRelay, 0, ROLLER_RELAY_SLAVE_ID, 4}, 23000},
  {2, 11, InputDevice::MCP3, {OutputType::ModbusRelay, 0, ROLLER_RELAY_SLAVE_ID, 6}, 23000},
  {3, 9, InputDevice::MCP3, {OutputType::ModbusRelay, 0, ROLLER_RELAY_SLAVE_ID, 8}, 23000},
  {4, 6, InputDevice::MCP3, {OutputType::ModbusRelay, 0, ROLLER_RELAY_SLAVE_ID, 10}, 23000},
  {5, 3, InputDevice::MCP3, {OutputType::ModbusRelay, 0, ROLLER_RELAY_SLAVE_ID, 12}, 23000},
  {6, 0, InputDevice::MCP3, {OutputType::ModbusRelay, 0, ROLLER_RELAY_SLAVE_ID, 14}, 23000}
};
